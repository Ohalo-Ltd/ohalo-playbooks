# Grafana documentation

Once you have deployed Grafana, you can open your browser and go to: `https://$URL/grafana` (replacing $URL with the actual URL of your server) to access the UI.

## IMPORTANT:
Please ***never*** share the admin password with anyone. Instead, please create a new user in the Grafana UI with role "Viewer".

1. As the admin user, click on "Users" in the users management section:
![Users Management](grafana-screenshots/user-management.png)

2. Click on New user and fill up the relevant info like the username, password, etc.
![New user](grafana-screenshots/click-on-new-user.png)

3. Once the user is created, go to the organization users section:
![Organization users section](grafana-screenshots/organization-user-section.png)

4. Make sure you have the "Viewer" permission selected:
![User permission](grafana-screenshots/user-permissions.png)

You can share this user's credentials with the end-users.


## Send Grafana Alerts via Slack (optional)

In this section, you will learn how to create a Slack app and obtain a webhook URL that can be used to publish alert messages to a Slack channel on your workspace. We will also cover how to configure a Grafana contact endpoint using the webhook URL.
**Note:** the slack notifications will only work if your DXR system (or the host running Grafana) has Internet access. In any case, the alerts will still appear on the Grafana Alerting section.

### Step 1: Create a Slack App

1. Log in to your Slack workspace.

2. Go to the [Slack API website](https://api.slack.com/apps) and click on the "Create an App" button.

3. Select the 'From scratch' options

4. Give your app a name and choose the workspace where you want to install the app. Click the "Create App" button.

### Step 2: Configure Webhooks

1. In your newly created app dashboard, navigate to the "Incoming Webhooks" section.

2. Toggle the switch to activate incoming webhooks for your app.

3. Scroll down and click on the "Add New Webhook to Workspace" button.

4. Choose the channel where you want to send the alert messages and click the "Authorize" button.

5. Make note of the generated "Webhook URL." This is the URL you will use to publish alert messages to the Slack channel.

## Step 3: Configure Grafana Slack Contact Endpoint

1. Override `grafana_alerting_slack_url` with your own Webhook Url that you got from the previous step so that it will be configured in `"{{ dxr_home }}/etc/grafana/provisioning/alerting/contact-points.yaml"`

2. On the UI, go to the "Alerting" -> "Contact Points" section click on the "View contact point" icon on the right of the "Slack-grafana-alerts" contact point.

4. On the top right section there is a "Test" button that allows you to verify the connection between Grafana and Slack, make sure it works.

For more information and advanced customization options, refer to the official documentation of [Slack API](https://api.slack.com/) and [Grafana Alerting](https://grafana.com/docs/grafana/latest/alerting/).