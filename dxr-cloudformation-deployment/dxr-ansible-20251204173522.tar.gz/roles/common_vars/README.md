# Common Vars role documentation

The purpose of this role is to declare common variables for different roles, and avoid circular dependencies. The main
reason to use a role to declare the defaults, is to allow to override those defaults if needed from inventory files,
based on the [ansible variable precendence](https://docs.ansible.com/ansible/latest/playbook_guide/playbooks_variables.html#understanding-variable-precedence).

The reason for not keeping these under `group_vars` is mainly to be able to override them from an inventory file. Production
environments can also use the `groups_vars/all.yml` file to override global variables if needed.

The role is declared as a dependency on the bootstrap role that is needed on every VM of the DXR stack, so the default
values for the common variables will be always available.

## Sample inventory file overriding the commons variables

You can override any of the values for the common variable from either the extra-vars command line parameter to the
ansible-playbook command or in an inventory file like:
```yaml
all:
  vars:
      dxr_version: "1234-dev-branch"
      dxray_es_index_name: "some-new-index-name"
  hosts:
    allinone:
      ansible_host: 127.0.0.1
```


## Common variable defaults

- `dxr_home`: the path where DXR's data and configuration is stored, default is `/opt/xray`
- `dxr_logs_directory`: the path where the logs are stored, default is `/var/log`
- `dxr_folder_datasources_path`: the path of the folder datasource feature, default is `/folder_datasources`
- `jvm_debug_ports_enabled`: flag that enables the JVM debug ports, this is NOT intended for Production use, default is `false`
- `common_extra_jvm_opts`: Default JVM options for all Java services using base-jvm. These options are used unless overridden by service-specific JVM options. Example: `"-Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false"`, default is `""`
- `dxray_es_index_name`: name of the elasticsearch index used by DXR, default is `dxr_docs`
- `elasticsearch_http_host`: Host for the Elasticsearch client API endpoint, defaults to `host.containers.internal`
- `elasticsearch_http_port`: Port for the Elasticsearch client API endpoint, defaults to `9200`. See: https://www.elastic.co/guide/en/elasticsearch/reference/current/modules-network.html#common-network-settings
- `rabbitmq_host`: The host where RabbitMQ is installed, defaults to `host.containers.internal`
- `rabbitmq_published_port`: Published port for the RabbitMQ endpoint, defaults to `5672`
- `rabbitmq_username`: Sets a username for RabbitMQ, defaults to `ohalo`
- `rabbitmq_vhost_xray_exporter`: Vhost used for the xray-exporter, needed for RabbitMQ initialization and xray-exporter-cs, defaults to `xray-exporter`
- `mysql_host`: The host where MySQL is installed, defaults to `host.containers.internal`
- `mysql_published_port`: Published port for the MySQL endpoint, defaults to `3306`
- `mysql_user`: Username used to connect to MySQL, defaults to `root`
- `mysql_url`: JDBC url used to connect to MySQL from java components, DO NOT override.
- `mysql_metadata_extractor_db`: The metadata-extractor db name, defaults to `metadata_extractor`
- `mysql_metadata_extractor_user`: Username used to connect to the MySQL metadata-extractor DB, defaults to `metadata_extractor`
- `mongo_host`: Host for the MongoDB endpoint, defaults to `host.containers.internal`
- `mongo_published_port`: Published port for the MongoDB endpoint, defaults to `27017`
- `seaweed_s3_http_host`: Host for the S3 endpoint, defaults to `host.containers.internal`
- `seaweed_s3_http_port`: Port for the S3 endpoint, defaults to `8333`
- `prometheus_host`: The host of the prometheus endpoint, defaults to `host.containers.internal`
- `prometheus_port`: Published port for the prometheus endpoint, defaults to `9090`
- `xray_api_url`: the API URL for the Nginx configuration file, defaults to `host.containers.internal`
- `xray_api_published_port`: Published port for the API endpoint, defaults to `8081`
- `document_ingester_elasticsearch_host`: The host of the document-ingester service, defaults to `host.containers.internal`
- `document_ingester_elasticsearch_port`: Published port for the document-ingester endpoint, defaults to `8090`
- `nlp_server_host`: The host of the nlp-server endpoint, defaults to `host.containers.internal`
- `nlp_server_port`: The port of the nlp-server endpoint, defaults to `8082`
- `dlp_syncer_host`: The host of the dlp-syncer endpoint, defaults to `host.containers.internal`
- `dlp_syncer_port`: Published port for the dlp-syncer endpoint, defaults to `8085`
- `xray_collibra_syncer_host`: The host of the xray-collibra-syncer endpoint, defaults to `host.containers.internal`
- `xray_collibra_syncer_port`: Published port for the xray-collibra-syncer endpoint, defaults to `8098`
- `xray_exporter_csv_host`: Host running the xray_exporter_csv, defaults to `host.containers.internal`
- `xray_exporter_csv_port`: Published port for xray-exporter-csv, defaults to `8190`
- `metadata_extractor_host`: The host of the metadata-extractor endpoint, defaults to `host.containers.internal`
- `metadata_extractor_port`: Published port for the metadata-extractor endpoint, defaults to `8078`
- `metadata_extractor_url`: Sets the endpoint for the metadata extractor, use for multi-server deployment
- `xray_diagnostics_host`: The host of the diagnostics endpoint, defaults to `host.containers.internal`
- `xray_diagnostics_port`: Published port for the xray-diagnostics endpoint, defaults to `8099`
- `identity_azure_ad_enabled`: Enables the deployment of identity-azure-ad, defaults to `false`
- `identity_azure_ad_oauth_url`: URL for the Azure AD integration OAuth (used on the frontends containers), defaults to `https://{{ server_url }}/azure-ad/oauth2/authorization/azure`
- `identity_azure_ad_ad_iam_manager`: Group for Super Admin Roles, see here https://docs.ohalo.co/advanced/azure-ad/ for more information
- `identity_azure_ad_sync_job_cron_expression`: Azure AD sync users job cron expression
- `identity_azure_ad_sync_job_cron_timezone`: Azure AD sync users job cron timezone
- `identity_azure_ad_azure_ad_tenant_id`: Directory (tenant) ID on the App registration on Azure, see here https://docs.ohalo.co/advanced/azure-ad/ for more information
- `identity_saml_enabled`: Enables the deployment of identity-saml, defaults to `false`
- `identity_saml_url`: URL for the SAML integration (used on the frontends containers), defaults to `https://{{ server_url }}/saml/saml2/authenticate/saml`
- `scim_enabled`: Enables SCIM APIs for user management, defaults to `false`
- `blob_storage_enabled`: Configures a blob storage as document-ingester-elasticsearch temporary storage (otherwise the default is the local filesystem) and as xray-api storage. Boolean, default is `true`
- `blob_storage_region`: Sets the region for the blob storage
- `blob_storage_endpoint`: Sets the endpoint for the blob storage
- `blob_storage_force_path_style`: Force S3 client to use "path style" requests (see https://docs.aws.amazon.com/AmazonS3/latest/userguide/VirtualHosting.html)
- `blob_storage_retry_max_attempts`: Maximum number of retry to connect to the blob storage, defaults to `30`
- `blob_storage_retry_base_delay`: Base retry delay to connect to the blob storage, defaults to `"PT5S"`
- `blob_storage_retry_max_delay`: Maximum retry delay to connect to the blob storage, defaults to `"PT60S"`
- `blob_storage_access_key_id`: Access key for the blob storage, you can use this command to generate the key id when using Seaweed (can be any alphanumerical string): `openssl rand -base64 2000 | tr -dc 'A-Za-z0-9' | fold -w 30 | head -n 1`.
- `blob_storage_secret_access_key`: Secret for the blob storage, you can use this command to generate the access key when using Seaweed (can be any long alphanumerical string): `openssl rand -base64 2000 | tr -dc 'A-Za-z0-9' | fold -w 60 | head -n 1`.
- `xray_console_api_docs_enabled`: flag that enables API Docs tab in Xray Console, default is `false`
- `on_demand_classifier_enabled`: Enables the On-Demand Classifier feature across both UI and API components, default is `false`
- `symmetric_encryption_secret`: Encryption for secrets using symmetric key. This key must be encoded using Base64 and be 256 bits long (you can type `openssl rand -base64 32` on your command line to generate one)
- `smb_jnq_connector_sid_name_lookup_enabled`: As our application discovers files in the SMB share, it collects metadata about them. This includes information about user and group who own the file. The Security Identifiers (SIDs) of the user and group will be captured. By default and supported by the SMB share, it's Local Security Authority (LSA) will be used to resolve names for these SIDs, default is `true`
- `elasticsearch_backup_blob_storage_access_key_id`: Access key used to backup Elasticsearch on SeaweedFS, you can use this command to generate the key id (can be any alphanumerical string): `openssl rand -base64 2000 | tr -dc 'A-Za-z0-9' | fold -w 30 | head -n 1`.
- `elasticsearch_backup_blob_storage_secret_access_key`: Secret used to backup Elasticsearch on SeaweedFS, you can use this command to generate the access key when using Seaweed (can be any long alphanumerical string): `openssl rand -base64 2000 | tr -dc 'A-Za-z0-9' | fold -w 60 | head -n 1`.
