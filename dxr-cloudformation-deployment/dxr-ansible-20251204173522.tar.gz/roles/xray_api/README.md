# xray-api role documentation

## xray-api

The `xray_api` role supports deploying and starting an `xray-api` container, including support for deploying the demo_files via the `folder_datasources` role.

### xray-api customization:

The defaults are in `roles/xray_api/defaults/main.yml` and can be overriden in the inventory file:

- `xray_api_image_version`: Version tag of the image that overrides the general `dxr_version` from the inventory file
- `xray_api_image_url`: URL for the image
- `xray_api_heap_size`: JVM Heap size, see the `-Xmx` section here: https://docs.oracle.com/en/java/javase/17/docs/specs/man/java.html#extra-options-for-java. Specifies the maximum size (in bytes) of the heap. This value must be a multiple of 1024 and greater than 2 MB. Append the letter k or K to indicate kilobytes, m or M to indicate megabytes, or g or G to indicate gigabytes.
- `xray_api_extra_jvm_opts`: Additional JVM options to pass to the Java application. These options override `common_extra_jvm_opts` when specified. If empty, `common_extra_jvm_opts` will be used instead. Example: `"-Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false"`
- `xray_api_web_token`: JSON Web Token (JWT) auth. This token must be encoded using Base64 and be at least 256 bits long (you can type `openssl rand -base64 64` on your command line to generate a 512 bits one)
- `xray_api_blob_storage_region`: Sets the region for the blob storage
- `xray_api_blob_storage_endpoint`: Sets the endpoint for the blob storage
- `xray_api_blob_storage_force_path_style`: Force S3 client to use "path style" requests (see https://docs.aws.amazon.com/AmazonS3/latest/userguide/VirtualHosting.html)
- `xray_api_blob_storage_retry_max_attempts`: The maximum number of retry attempts for a request. Must be a positive integer.
- `xray_api_blob_storage_retry_base_delay`: The initial delay before retrying a failed request. Retries follow an exponential backoff strategy, increasing up to the maximum delay. Must be a positive duration, formatted as an ISO 8601 duration.
- `xray_api_blob_storage_retry_max_delay`: The maximum delay before retrying a failed request. Must be a positive duration, formatted as an ISO 8601 duration.
- `xray_api_on_demand_classifier_client_max_body_size`: Sets the max body size for the On-Demand Classifier feature
- `xray_api_on_demand_classifier_upload_size_limit`: Sets the maximum size of any file that can be uploaded to the On-Demand Classifier
- `xray_api_on_demand_classifier_jobs_time_to_live`: How long job results are available for, defined as an ISO8601 duration
- `xray_api_on_demand_classifier_jobs_recrawl_dispatch_backoff_interval`: Duration between recrawl attempts, defined as an ISO8601 duration
- `xray_api_on_demand_classifier_jobs_recrawl_dispatch_max_attempts`: Maximum number of recrawl attempts per job
- `xray_api_on_demand_classifier_jobs_document_categorizer_job_dispatch_backoff_interval`: Duration between document categorizer job attempts, defined as an ISO8601 duration
- `xray_api_on_demand_classifier_jobs_document_categorizer_job_dispatch_max_attempts`: Maximum number of document categorizer job attempts per job
- `xray_api_on_demand_classifier_jobs_metadata_extractor_job_dispatch_backoff_interval`: Duration between metadata extractor job attempts, defined as an ISO8601 duration
- `xray_api_on_demand_classifier_jobs_metadata_extractor_job_dispatch_max_attempts`: Maximum number of metadata extractor job attempts per job
- `xray_api_on_demand_classifier_jobs_file_upload_timeout`: Sets the max time allowed for uploading files to blob storage
- `xray_api_on_demand_classifier_initial_crawl_dispatch_backoff_interval`: Duration between attempts to crawl On-Demand Classifier datasources on creation
- `xray_api_on_demand_classifier_initial_crawl_dispatch_max_attempts`: Maximum number of crawl On-Demand Classifier datasources on creation
- `xray_api_on_demand_classifier_cleanup_interval`: Duration between cleanup job runs, defined as an ISO8601 duration
- `xray_api_on_demand_classifier_delegated_access_token_lifetime`: Duration of the delegated access token that is associated with each on-demand classifier job that allows the job to execute tasks on behalf of the user for a limited time, defined as an ISO8601 duration.
- `xray_api_spring_jpa_properties_hibernate_cache_use_second_level_cache`: Use Hibernate second level cache
- `xray_api_spring_jpa_properties_hibernate_cache_use_query_cache`: Use Hibernate query cache
- `xray_api_cache_ehcache_time_to_live_seconds`: Ehcache TTL
- `xray_api_frontend_app_url`: URL of the frontend application that the API will communicate with. Defaults to `https://{{ server_url }}` for single-server deployments. For multi-server deployments, set this to the frontend server URL (e.g., `https://{{ hostvars['frontend']['server_url'] }}`)
- `xray_api_generate_full_urls`: Whether to generate full URLs for the external API responses. Defaults to `false`
- `xray_api_cors_allowed_origins`: comma separated list of CORS (Cross-Origin Resource Sharing) allowed origins. Defaults to `{{ xray_api_frontend_app_url }}/` (automatically derived from the frontend app URL). Additional origins can be added by overriding this variable (e.g., `{{ xray_api_frontend_app_url }}/,http://localhost:3000/`)
- `xray_api_index_service_export_page_size`: Number of indexed files to read from Elasticsearch at a time during the export process, default 1000

The following variables have their default definitions in `common_vars/defaults/main.yml` since they are common variables:
- `common_extra_jvm_opts`: Default JVM options for all Java services using base-jvm. These options are used unless overridden by service-specific JVM options. Example: `"-Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false"`
- `xray_api_url`: the API URL for the Nginx configuration file, if not set it will default to `host.containers.internal`
- `xray_api_published_port`: Published port for the API endpoint
- `blob_storage_enabled`: Configures a blob storage as document-ingester-elasticsearch temporary storage (otherwise the default is the local filesystem) and as xray-api storage. Boolean, default is `true`
- `blob_storage_region`: Sets the region for the blob storage
- `blob_storage_endpoint`: Sets the endpoint for the blob storage
- `blob_storage_force_path_style`: Force S3 client to use "path style" requests (see https://docs.aws.amazon.com/AmazonS3/latest/userguide/VirtualHosting.html)
- `blob_storage_retry_max_attempts`: Maximum number of retry to connect to the blob storage, default to `30`
- `blob_storage_retry_base_delay`: Base retry delay to connect to the blob storage, defaults to `"PT5S"`
- `blob_storage_retry_max_delay`: Maximum retry delay to connect to the blob storage, defaults to `"PT60S"`
- `blob_storage_access_key_id`: Access key for the blob storage, you can use this command to generate the key id when using Seaweed (can be any alphanumerical string): `openssl rand -base64 2000 | tr -dc 'A-Za-z0-9' | fold -w 30 | head -n 1`.
- `blob_storage_secret_access_key`: Secret for the blob storage, you can use this command to generate the access key when using Seaweed (can be any long alphanumerical string): `openssl rand -base64 2000 | tr -dc 'A-Za-z0-9' | fold -w 60 | head -n 1`.
