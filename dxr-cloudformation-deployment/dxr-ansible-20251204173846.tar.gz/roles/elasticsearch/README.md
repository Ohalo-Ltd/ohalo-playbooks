# Elasticsearch role documentation

## Elasticsearch

What the role currently supports:
- Deploy a container that runs a single node Elasticsearch cluster
- Deploy a 3-nodes Elasticsearch cluster
- Configure monitoring
- Handle the SSL certificates for the Elasticsearch service

What remains to do:
- set up limits for nofile and memlock just for podman/ohalo user, instead of globally, and merge it back in the Elasticsearch role
- adapting the configuration based on the host server's specs

### Elasticsearch Customization

The defaults are in `roles/elasticsearch/defaults/main.yml` and can be overriden in the inventory file:

- `elasticsearch_image_version`: Elasticsearch version
- `elasticsearch_image_url`: URL for the Elasticsearch image
- `elasticsearch_transport_port`: Port for communication between nodes of a cluster, only for multi-nodes setups, default to `9300`. See: https://www.elastic.co/guide/en/elasticsearch/reference/current/modules-network.html#common-network-settings
- `elasticsearch_java_memory_in_mb`: Java heap size, should be no more than 50% of the total memory of the host server and _never_ above 26GB at most, as per the official recommendations: https://www.elastic.co/guide/en/elasticsearch/reference/current/docker.html#docker-set-heap-size
- `elasticsearch_log_level`: Log level for Elasticsearch, default is "INFO", valid values from least to most verbose are: OFF, FATAL, ERROR, WARN, INFO, DEBUG, and TRACE. See https://www.elastic.co/guide/en/elasticsearch/reference/current/logging.html#configuring-logging-levels for more details
- `elasticsearch_single_node_name`: Node name for single node setups
- `elasticsearch_cluster_name`: Cluster name, please choose a unique name, otherwise nodes might join the wrong cluster.
- `internal_ip`: Usually set in the Ansible inventory file, used for cluster communications (called 'transport IP' in the Elasticsearch documentation) and API requests through HAProxy in multi-nodes clusters. Ideally, these should be internal IP addresses (the communications are SSL encrypted so it's possible to use public IP addresses, although to reduce the attack surface, it's better to keep the transport ports isolated from the wide internet if possible).
- `elasticsearch_backup_blob_storage_endpoint_protocol`: Protocol used when making an Elasticsearch snapshot (backup) on Seaweed S3 endpoint, defaults to `http` for now.
- `elasticsearch_backup_path_style_access`: Option used when making an Elasticsearch snapshot (backup) on Seaweed S3 endpoint, defaults to `true`

The defaults are in `roles/common_vars/defaults/main.yml` and can be overriden in the inventory file:
- `elasticsearch_http_host`: Host for the Elasticsearch client API endpoint
- `elasticsearch_http_port`: Port for the Elasticsearch client API endpoint, defaults to `9200`. See: https://www.elastic.co/guide/en/elasticsearch/reference/current/modules-network.html#common-network-settings

This variable has no default and is set in the inventory file:
- `elasticsearch_elastic_password`: Sets the password for superuser `elastic`, see: https://www.elastic.co/guide/en/elasticsearch/reference/current/configuring-stack-security.html#stack-start-with-security or https://www.elastic.co/guide/en/elasticsearch/reference/current/docker.html#_configure_and_start_the_cluster. If you want to change the superuser `elastic`'s password, simply change the value of `elasticsearch_elastic_password` and re-run the deployment.

#### Elasticsearch Certificates
The TLS certificates are generated automatically on the first deployment. The deployment checks if `{{ dxr_home }}/certs/index/` is empty, if it is the certs will be generated (or pulled them from where they were generated, in the case of clusters). If you want to regenerate them, you need to stop the Elasticsearch containers, delete everything in `{{ dxr_home }}/certs/index/*` and re-run the Elasticsearch deployment. Please note that this will create a new CA certificate as well that will need to be propagated to the other servers of the stack, so a full redeployment is required, not just the Elasticsearch nodes.