# folder_datasources role documentation

## folder_datasources

The `folder_datasources` role creates the directory used for the folder connector feature and deploys a set of demo files. Once the `/folder_datasources` directory is created, Ansible will not modify it again.