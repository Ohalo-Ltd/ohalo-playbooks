# Grafana Dashboards

You can just drop dashboards as JSON files in `/opt/xray/etc/grafana/dashboards/` and they will populate Grafana's dashboards page on startup. See `etc/grafana/provisioning/dashboards/ohalo-dashboard.yml` for that configuration.

Here is the official repository for dashboards: https://grafana.com/grafana/dashboards/

Please add tested production dashboards here so they get added during deployments.

## IMPORTANT NOTE: 

You will need to replace the variables in the JSON file you download from https://grafana.com/grafana/dashboards/ for them to work when provisioning via `/opt/xray/etc/grafana/dashboards/`, notably `datasource`. 

For example in `prometheus-2-0-overview_rev2.json` that you just downloaded from grafana.com: replace `"datasource": "${DS_PROMETHEUS}"` with `"datasource": "Prometheus"`. Please note the datasource section can also use the following format, in which case you would aslo need to replace the variable with simply `"uid": "Prometheus"`:
```
"datasource": {
       "type": "prometheus",
       "uid": "Prometheus"
     },
```