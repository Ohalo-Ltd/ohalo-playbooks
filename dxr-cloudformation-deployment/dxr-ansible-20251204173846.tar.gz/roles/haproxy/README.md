# HAProxy role documentation

## HAProxy

The `haproxy` role supports deploying and starting an `haproxy` container. HAProxy is used to dispatch requests to Elasticsearch and nlp-server in multi-servers setups.

### haproxy customization:
- `haproxy_image_url`: URL for the image
- `haproxy_image_version`: Version tag for the image
- `haproxy_stats_port`: Published port for the HAProxy stats page. This page is only available from the host server's local loopback (see the stats section on the haproxy.cfg template).