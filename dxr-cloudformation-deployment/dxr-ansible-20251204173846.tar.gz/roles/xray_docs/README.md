# xray-docs role documentation

## xray-docs

This role deploys an `xray-docs` container, that provides local documentation for Data X-Ray.

### xray-docs customization

The defaults are in `roles/xray_docs/defaults/main.yml` and can be overriden in the inventory file:
- `xray_docs_host`: The URL where the service can be reached
- `xray_docs_port`: Published port for the endpoint
- `xray_docs_image_url`: URL for the image
- `xray_docs_image_version`: Version tag of the image that overrides the general `dxr_version` from the inventory file