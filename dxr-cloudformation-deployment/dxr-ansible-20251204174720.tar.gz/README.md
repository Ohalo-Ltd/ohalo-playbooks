# Ohalo Ansible

The goal of this project is to deploy the Data X-ray stack using Ansible.

<!--toc:start-->

- [Ohalo Ansible](#ohalo-ansible)
  - [Table of Contents](#table-of-contents)
  - [How does Ansible work?](#how-does-ansible-work)
  - [Prerequisites](#prerequisites)
  - [Deployment](#deployment)
    - [Server minimum requirements for the Data X-Ray deployment](#server-minimum-requirements-for-the-data-x-ray-deployment)
      - [General prerequisites](#general-prerequisites)
      - [Single server](#single-server)
      - [Multi-servers cluster](#multi-servers-cluster)
    - [Deploying a single all-in-one DXR server](#deploying-a-single-all-in-one-dxr-server)
      - [Optional features:](#optional-features)
    - [Deploying a multi-servers DXR cluster](#deploying-a-multi-servers-dxr-cluster)
    - [Additional note:](#additional-note)
      - [Deployment customization](#deployment-customization)
      - [Privilege escalation](#privilege-escalation)
      - [Linux users and ssh keys](#linux-users-and-ssh-keys)
      - [Common variables](#common-variables)
      - [Bootstrap](#bootstrap)
      - [configure_frontend_containers](#configurefrontendcontainers)
      - [configure_java_containers](#configurejavacontainers)
      - [validate_identity_config](#validateidentityconfig)
      - [create_log_files](#createlogfiles)
      - [document-ingester-elasticsearch](#document-ingester-elasticsearch)
      - [Elasticsearch](#elasticsearch)
      - [folder_datasources (including demo files)](#folderdatasources-including-demo-files)
      - [Grafana](#grafana)
      - [HAProxy](#haproxy)
      - [host_monitoring](#hostmonitoring)
      - [identity-azure-ad](#identity-azure-ad)
      - [dlp-syncer](#dlp-syncer)
      - [MongoDB](#mongodb)
      - [MySQL](#mysql)
      - [Nginx](#nginx)
      - [nlp-server](#nlp-server)
      - [Prometheus](#prometheus)
      - [RabbitMQ](#rabbitmq)
      - [SeaweedFS](#seaweedfs)
      - [xray-api](#xray-api)
      - [xray-collibra-syncer](#xray-collibra-syncer)
      - [xray-console](#xray-console)
      - [xray-diagnostics](#xray-diagnostics)
      - [xray-docs](#xray-docs)
      - [xray-exporter-csv](#xray-exporter-csv)
      - [metadata-extractor](#metadata-extractor)
      - [xray-ui](#xray-ui)
    - [Cluster maintenance](#cluster-maintenance)
      - [Restarting the stack](#restarting-the-stack)
      - [Stopping the stack](#stopping-the-stack)
      - [Updating the stack (minor version without manual upgrade procedure)](#updating-the-stack-minor-version-without-manual-upgrade-procedure)
      - [Useful Podman commands](#useful-podman-commands)
    - [Current limitations](#current-limitations)
      - [Elasticsearch cluster](#elasticsearch-cluster)
      - [Upgrades](#upgrades)
      - [Nginx SSL certificates](#nginx-ssl-certificates)
      - [Prune the dangling container images](#prune-the-dangling-container-images)
      - [Supported Ansible version](#supported-ansible-version)
      - [Passwords](#passwords)
  - [Post-Deployment](#post-deployment)
    - [Back up the deployment information](#back-up-the-deployment-information)
    - [Change the console admin password](#change-the-console-admin-password)
    - [Create a user with the 'viewer' role on Grafana](#create-a-user-with-the-viewer-role-on-grafana)

<!--toc:end-->

## How does Ansible work?

Ansible doesn't require any agent, it works by connecting to a remote server via ssh. So all you need is:

- Ansible installed on your local environment or on your control node
- a remote server with a privileged user, accessible via ssh (please see the 'Privilege escalation' section below for more information)

## Prerequisites

In order to use this repository, you will need the following on your local environment:

- Python 3. Many RHEL images will come with Python 3 pre-installed. You may check this by running `python3 --version`. If necessary, install Python using
  ```
  dnf install python3
  ```

- Python 3 dependencies. Install the following Python dependencies.
  ```
  python3 -m pip install --user --upgrade pip setuptools
  ```

- Ansible Core. On a RHEL 8 machine, you can install it using:
  ```
  dnf install ansible-core
  ```

  On other operating systems, the most common way of installing Ansible is to use Python3 and pip:
  ```
  # Install Ansible Core <= 2.16
  python3 -m pip install --user 'ansible-core<=2.16'
  ```
  Please refer to https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html#installing-and-upgrading-ansible-with-pip for more information.

  IMPORTANT: Please make sure you are installing Ansible <=2.16, as ansible-core >=2.17 drops support for Python 3.6 for target executions, which breaks RHEL 8 deployments. Since we are targeting RHEL8, the Ansible version officially supported is ansible-core 2.16. Ansible-core 2.16 will receive critical security updates through the remaining lifecycle of RHEL 8. Please see here for more information: https://github.com/ansible/ansible/issues/83357#issuecomment-2150254754. You can read this section regarding the [supported Ansible version](#supported-ansible-version) for more information.

- Ansible collections. You must run the following command inside the `ohalo-ansible` directory:
  ```
  ansible-galaxy install -r requirements.yml
  ```
  Please refer to https://docs.ansible.com/ansible/latest/collections_guide/collections_installing.html#install-multiple-collections-with-a-requirements-file for more information

- `passlib` and `bcrypt`. These libraries are used to encrypt the Prometheus password. They require `rust` and `cargo` to be installed beforehand. You may confirm that rust and cargo are installed using `rust -v` and `cargo -v`. If necessary, install them using
  ```
  dnf install rust cargo
  ```
  Then, install `passlib` and `bcrypt`
  ```
  python3 -m pip install --user passlib bcrypt
  ```

## Deployment

This section will describe how to deploy the Data X-Ray stack. Please be sure to check the [Current limitations section](#current-limitations) as well.

### Server minimum requirements for the Data X-Ray deployment

These values are a suggestion. Please contact Ohalo support to properly assess your needs and cluster sizing.

#### General prerequisites

We recommend using:

- The operating system should be Red Hat Enterprise Linux 8 (8.9+), or one of its clones: Rocky Linux 8 and AlmaLinux 8.
- A user with ssh access and `sudo` privileges that Ansible will use for the deployment. If you are using an alternative to `sudo`, please note that the Ansible deployment supports existing privilege escalation tools like sudo, su, pfexec, doas, pbrun, dzdo, ksu, runas, machinectl and others, see https://docs.ansible.com/ansible/latest/playbook_guide/playbooks_privilege_escalation.html#understanding-privilege-escalation-become for more information
- We use the name `ohalo` for the unprivileged user running the containers, so please avoid having a user already named `ohalo` on the machine

#### Single server

The minimum requirements for the DXR stack running on a single server are:

- At least 32G of RAM
- At least 8 vCPUs
- At least 100G of disk

#### Multi-servers cluster

For a multi-servers production cluster, at the moment we recommend 7 servers:

- Frontend server: 4 vCPUs, 8GB+ RAM, 50GB+ disk
- Backend server: 8 vCPUs, 16GB+ RAM, 1TB+ disk
- Ingester server: 32 vCPUs+, 64GB+ RAM, 1TB+ disk
- NLP server: 16 vCPUs, 16GB+ RAM, 1TB+ disk
- 3 Elasticsearch nodes: 4 vCPUs, 16GB+ RAM, 1TB+ disk (x3)

### Deploying a single all-in-one DXR server

For this, you will need a single server that you can access through ssh to a privileged user, please see [the recommended specs above](#single-server).

First, you will need to create an inventory file: copy `inventory-example-dxr-single-server.json` and edit that file with the appropriate values for your environment. Edit the credentials section with the passwords of your choice (please read [the password section below](#passwords) for more information about passwords). `ghcr_token` is an access token to Ohalo's private package registry ghcr.io that containers the Data X-Ray container images. If you do not know what your access token is please contact your customer success representative. Finally, replace `dxr_version` with the version of Data X-Ray you want to run, see the release notes section of https://docs.ohalo.co/ for a list of available version tags.

You will then need to run the following command:

```sh
ansible-playbook -v -i inventory-example-dxr-single-server.json -u username deploy-dxr-single-server-playbook.yml
```

Please replace `username` in the command above with the user you wish to use to ssh to your server.

#### Optional features:

Some features of the stack are optional. For example, if you want to use Microsoft Entra ID/Azure Active Directory for login, you will want to deploy the optional identity-azure-ad container, to do so please edit the `Azure AD configuration` section in the inventory file.

Please refer to the role's documentation for more information.

Additional optional features are listed in the `Optional components` section of the inventory file.

### Deploying a multi-servers DXR cluster

For this, you will need to create 7 servers that you can access through ssh to a privileged user, please see [the recommended specs above](#multi-servers-cluster).

First, you will need to create an inventory file: copy `inventory-example-dxr-cluster.json` and edit that file with the appropriate values for your environment. Edit the credentials section with the passwords of your choice (please read [the password section below](#passwords) for more information about passwords). `ghcr_token` is an access token to Ohalo's private package registry ghcr.io that containers the Data X-Ray container images. If you do not know what your access token is please contact your customer success representative. Finally, replace `dxr_version` with the version of Data X-Ray you want to run, see the release notes section of https://docs.ohalo.co/ for a list of available version tags.

You can then deploy the cluster using:

```sh
ansible-playbook -v -i inventory-example-dxr-cluster.json -u username deploy-dxr-cluster-playbook.yml
```

Please replace `username` in the command above with the user you wish to use to ssh to your server.

### Additional note:

#### Deployment customization

Each component of the stack supports a number of customizations to fit the requirements of each deployment. Please refer to the documentation for each role, located in its own directory, listed below. Please see here for more information about Ansible roles: https://docs.ansible.com/ansible/latest/playbook_guide/playbooks_reuse_roles.html

#### Converting Ansible inventory to JSON

We have added an inventory file for single server deployment, and also converted the inventory files for single server and multi-server cluster from YAML to JSON. YAML is a superset of JSON, and Ansible supports both, but JSON has better support and tooling is typically of higher quality and more mature. YAML's white-space sensitivity and rather unusual types can also cause errors. For these reasons, we've decided to switch to JSON.

We recommend converting all Ansible inventory files to JSON for consistency.

Existing inventory files can be converted from YAML to JSON using the following command:
```
cat inventory-example-cluster.yml | python3 -c "import json,yaml,sys;yaml_inv=yaml.safe_load(sys.stdin);print(json.dumps(yaml_inv, indent=2));"
```

Conversely, in case you need to, you can also do the reverse and convert JSON to YAML using:
```
cat inventory-example-cluster.json | python3 -c "import json,yaml,sys;json_inv=json.load(sys.stdin);print(yaml.dump(json_inv));"
```

We have also moved all the variables set in `--extra-vars` in the default deployment command to the inventory files, since it's easier to manage a configuration file rather than a long command.

#### Privilege escalation

Ansible uses existing privilege escalation systems to execute tasks with root privileges or with another user's permissions. By default, Ansible uses:

- user `root`
- `sudo` as the privilege escalation method

You can override those with the following:

- `--become-user=<user>` to use a different user than root for those tasks
- `--become-method=<method>` to use a different privilege escalation method. Valid choices: [ sudo | su | pbrun | pfexec | doas | dzdo | ksu | runas | machinectl ]

#### Linux users and ssh keys

At the moment, we create a single user on the targeted servers:

- `ohalo`, an unprivileged user that will run the containers, which is mandatory,

We will deploy public ssh keys for remote access to those users if you set `bootstrap_deploy_ssh_public_keys` to true. By default, we will deploy a set of Ohalo's engineers public ssh keys. You can override this by providing a different set of ssh public keys using `bootstrap_ssh_public_keys_location`, please see [the bootstrap role documentation](roles/bootstrap/README.md) for more information.

#### Common variables

These variables, are shared across component and can be overridden in the same way as the other role variables. They are
defined on the `common_vars` role; refer to its [README.md](roles/common_vars/README.md) file for details.

#### Bootstrap

Please refer to [the bootstrap role documentation here.](roles/bootstrap/README.md)

#### configure_frontend_containers

Please refer to [configure_frontend_containers role documentation here.](roles/configure_frontend_containers/README.md)

#### configure_java_containers

Please refer to [configure_java_containers role documentation here.](roles/configure_java_containers/README.md)

### validate_identity_config

Please refer to [validate_identity_config role documentation here.](roles/validate_identity_config/README.md)

#### create_log_files

Please refer to [create_log_files role documentation here.](roles/create_log_files/README.md)

#### document-ingester-elasticsearch

Please refer to [document-ingester-elasticsearch role documentation here.](roles/document_ingester_elasticsearch/README.md)

#### Elasticsearch

Please refer to [elasticsearch role documentation here.](roles/elasticsearch/README.md)

#### folder_datasources (including demo files)

Please refer to [folder_datasources role documentation here.](roles/folder_datasources/README.md)

#### Grafana

Please refer to [Grafana role documentation here.](roles/grafana/README.md)

#### HAProxy

Please refer to [HAProxy role documentation here.](roles/haproxy/README.md)

#### host_monitoring

Please refer to [host_monitoring role documentation here.](roles/host_monitoring/README.md)

#### identity-azure-ad

Please refer to [identity-azure-ad role documentation here.](roles/identity_azure_ad/README.md)

#### dlp-syncer

Please refer to [dlp-syncer role documentation here.](roles/dlp_syncer/README.md)

#### MongoDB

Please refer to [MongoDB role documentation here.](roles/mongo/README.md)

#### MySQL

Please refer to [MySQL role documentation here.](roles/mysql/README.md)

#### Nginx

Please refer to [Nginx role documentation here.](roles/nginx/README.md)

#### nlp-server

Please refer to [nlp-server role documentation here.](roles/nlp_server/README.md)

#### Prometheus

Please refer to [Prometheus role documentation here.](roles/prometheus/README.md)

#### RabbitMQ

Please refer to [RabbitMQ role documentation here.](roles/rabbitmq/README.md)

#### SeaweedFS

Please refer to [SeaweedFS role documentation here.](roles/seaweed/README.md)

#### xray-api

Please refer to [xray-api role documentation here.](roles/xray_api/README.md)

#### xray-collibra-syncer

Please refer to [xray-collibra-syncer role documentation here.](roles/xray_collibra_syncer/README.md)

#### xray-console

Please refer to [xray-console role documentation here.](roles/xray_console/README.md)

#### xray-diagnostics

Please refer to [xray-diagnostics role documentation here.](roles/xray_diagnostics/README.md)

#### xray-docs

Please refer to [xray-docs role documentation here.](roles/xray_docs/README.md)

#### xray-exporter-csv

Please refer to [xray-exporter-csv role documentation here.](roles/xray_exporter_csv/README.md)

#### metadata-extractor

Please refer to [metadata-extractor role documentation here.](roles/metadata_extractor/README.md)

#### xray-ui

Please refer to [xray-ui role documentation here.](roles/xray_ui/README.md)

### Cluster maintenance

#### Starting and restarting the stack

Restart and start are the same thing here: if the container is not up, then they will simply be started, and not restarted.

You can start or restart all the containers of the stack by using the `restart` tag, for that all you need to do is run the same command you used for deployment with the additional option `--tags "restart"`, here is an example:

```sh
ansible-playbook -v -i inventory-example-dxr-single-server.json -u username deploy-dxr-single-server-playbook.yml \
--tags "restart"
```

You can also use `restart_<role_name>` to restart the containers associated to a role. You can use multiple tags, separating them with a comma, here is an example with all the available restart flags:

`--tags "restart_dlp_syncer,restart_document_ingester_elasticsearch,restart_elasticsearch,restart_grafana,restart_haproxy,restart_host_monitoring,restart_identity_azure_ad,restart_identity_saml,restart_metadata_extractor,restart_mongo,restart_mysql,restart_nginx,restart_nlp_server,restart_xray_docs,restart_prometheus,restart_rabbitmq,restart_seaweed,restart_xray_api,restart_xray_collibra_syncer,restart_xray_console,restart_xray_diagnostics,restart_xray_exporter_csv,restart_xray_ui"`

Please note that, if you are using optional components like `dlp-syncer`, `xray-collibra-syncer`, `identity-azure-ad`, or `identity-saml`, you will need the associated flags (`dlp_syncer_enabled`, `identity_azure_ad_enabled`, `identity_saml_enabled`, or `xray_collibra_syncer_enabled`) set to `true` for the tags `restart_dlp_syncer`, `restart_identity_azure_ad`, `restart_identity_saml`, or `restart_xray_collibra_syncer` to work.

For more information on how to use tags: https://docs.ansible.com/ansible/latest/playbook_guide/playbooks_tags.html#selecting-or-skipping-tags-when-you-run-a-playbook

#### Stopping the stack

You can stop all the containers of the stack by using the `stop` tag, for that all you need to do is run the same command you used for deployment with the additional option `--tags "stop"`, here is an example:

```sh
ansible-playbook -v -i inventory-example-dxr-single-server.json -u username deploy-dxr-single-server-playbook.yml \
--tags "stop"
```

You can also use `stop_<role_name>` to restart the containers associated to a role. You can use multiple tags, separating them with a comma, here is an example with all the available stop flags:

`--tags "stop_dlp_syncer,stop_document_ingester_elasticsearch,stop_elasticsearch,stop_grafana,stop_haproxy,stop_host_monitoring,stop_identity_azure_ad,stop_identity_saml,stop_metadata_extractor,stop_mongo,stop_mysql,stop_nginx,stop_nlp_server,stop_xray_docs,stop_prometheus,stop_rabbitmq,stop_seaweed,stop_xray_api,stop_xray_collibra_syncer,stop_xray_console,stop_xray_diagnostics,stop_xray_exporter_csv,stop_xray_ui"`

Please note that, if you are using optional components like `dlp-syncer`, `xray-collibra-syncer`, `identity-azure-ad`, or `identity-saml`, you will need the associated flags (`dlp_syncer_enabled`, `identity_azure_ad_enabled`, `identity_saml_enabled`, or `xray_collibra_syncer_enabled`) set to `true` for the tags `stop_dlp_syncer`, `stop_identity_azure_ad`, `stop_identity_saml`, or `stop_xray_collibra_syncer` to work.

For more information on how to use tags: https://docs.ansible.com/ansible/latest/playbook_guide/playbooks_tags.html#selecting-or-skipping-tags-when-you-run-a-playbook

#### Updating the stack (minor version without manual upgrade procedure)

At the moment, we can only support automated upgrades that do not require manual steps outside of updating the configuration files/environment variables/containers release tags. Upgrades can otherwise still be achieved by running those steps manually. We will add support for automated major manual upgrades later on.

To upgrade a server or a cluster, simply bump the `dxr_version` variable to the desired version in the inventory file and re-run the deployment. For example:

```sh
ansible-playbook -v -i inventory-example-dxr-single-server.json -u username deploy-dxr-single-server-playbook.yml
```

#### Useful Podman commands

Here are a few useful podman commands (must be run as the user running the containers, usually user `ohalo`):

```sh
# List all containers
podman ps -a

# Execute a command on the container's shell
podman exec -it nginx cat /etc/nginx/nginx.conf

# Access the container's shell
podman exec -it nginx sh

# Stop all containers (it is important to remove the container after stopping it, otherwise any modification on the container is preserved)
podman stop -a && podman rm -a

# Remove dangling images
podman image prune -a -f
```

For a complete list of podman commands, see: https://docs.podman.io/en/latest/Commands.html

### Current limitations

At the moment, there are a few limitations that we will strive to reduce as much as possible:

#### Elasticsearch cluster

The current deployment is limited to a 3-nodes cluster. Please be sure to use a unique name for the Elasticsearch cluster name (`elasticsearch_cluster_name`), since Elasticsearch nodes try to join the cluster based on that name, and a node could potentially join the wrong cluster in certain conditions.

#### Upgrades

At the moment, we can only support automated upgrades that do not require manual steps outside of updating the configuration files/environment variables/containers release tags. Upgrades can otherwise still be achieved by running those steps manually. We will add support for automated major manual upgrades later on.

#### Nginx SSL certificates

You can provide your own certificates using the `nginx_path_to_ssl_cert_and_key_dir` variable, please refer to [the Nginx documentation](roles/nginx/README.md) for more information. Otherwise the deployment will generate self-signed OpenSSL certificates.

If you want to update or re-generate the certificates, please delete the crt and key files in `{{ dxr_home }}/certs`, and re-run the Ansible deployment.

#### Supported Ansible version

Because we target RHEL 8 and it comes by default with Python 3.6.8, it would cause issues if you are running Ansible-core >=2.17 on your control node. The version of ansible-core chosen for RHEL 8 is ansible-core 2.16. Ansible-core 2.16 will receive critical security updates through the remaining lifecycle of RHEL8.

We recommend using an RHEL 8 host for your control node, or use a RHEL 8 based execution environment, in order to manage RHEL 8 hosts, in which case you can simply use `dnf install ansible-core`, that will install the correct version.

You can read more about this here:

- https://forum.ansible.com/t/python-3-7-impact-on-el8-future-for-el9/6229/13
- https://github.com/ansible/ansible/issues/83357#issuecomment-2150254754
- https://github.com/ansible/ansible/issues/83357#issuecomment-2176414683

#### Passwords

Please ensure that you don't use reserved characters could break URL parsing, the following are reserved characters: `:`, `/`, `?`, `#`, `[`, `]`, `@`, `!`, `$`, `&`, `'`, `(`, `)`, `*`, `+`, `,`, `;` and `=`. In general, entropy is more important than complexity, so a long alphanumeric password works great too. We will try to resolve that by adding URL encoding where appropriate.

## Post-Deployment

This is a list of steps that we recommend running once the deployment has completed.

### Back up the deployment information

We recommend backing up:

1. the passwords used for the deployment in a password manager
1. the inventory file used for the deployment
1. the certificate bundle for ElasticSearch (optional)

### Change the console admin password

Once you have logged into the frontend console for the first time, we recommend changing the default admin password to something unique.

### Create a user with the 'viewer' role on Grafana

We recommend logging into Grafana as the admin user and create a user only with the viewer role. This is the user that should primarily be used for Grafana outside of administrative tasks.
