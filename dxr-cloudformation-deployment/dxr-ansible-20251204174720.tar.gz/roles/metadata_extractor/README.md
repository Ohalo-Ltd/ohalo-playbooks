# metadata-extractor role documentation

## metadata-extractor

The `metadata_extractor` role supports deploying and starting an `metadata-extractor` container.

### metadata-extractor customization:

The defaults are in `roles/metadata_extractor/defaults/main.yml` and can be overridden in the inventory file:
- `metadata_extractor_image_url`: URL for the image
- `metadata_extractor_image_version`: Version tag for the image
- `metadata_extractor_extra_jvm_opts`: Additional JVM options to pass to the Java application. These options are appended to the standard JVM configuration. Example: `"-Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false"`

The following variables have their default definitions in `common_vars/defaults/main.yml` since they are common variables:
- `metadata_extractor_host`: The host of the service
- `metadata_extractor_port`: Published port for the metadata-extractor endpoint
- `metadata_extractor_url`: Sets the endpoint for the metadata extractor, use for multi-server deployment
- `metadata_extractor_messaging_listener_max_concurrency`: Can be used to tune the performance of metadata-extractor by scaling the number of threads processing RabbitMQ messages for different parts of the extractor job
- `metadata_extractor_cleanup_job_terminated_job_lifetime`: The time after a job terminates until its eligible for cleanup
- `metadata_extractor_cleanup_job_cron_expression`: When the cleanup job will run
- `metadata_extractor_cleanup_job_cron_timezone`: The timezone corresponding to the cleanup job cron expression
