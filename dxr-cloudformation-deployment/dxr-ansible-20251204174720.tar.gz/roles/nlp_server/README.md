# nlp-server role documentation

## nlp-server

The `nlp_server` role supports deploying and starting an `nlp-server` container.

### nlp-server customization:

The defaults are in `roles/nlp_server/defaults/main.yml` and can be overriden in the inventory file:
- `nlp_server_image_url`: URL for the image
- `nlp_server_image_version`: Version tag of the image that overrides the general `dxr_version` from the inventory file
- `nlp_server_gunicorn_workers`: Number of worker threads per server
- `nlp_server_gunicorn_max_requests`: The number of requests each worker can handle before being recycled, releasing any resources that they might hold.

The following variables have their default definitions in `common_vars/defaults/main.yml` since they are common variables:
- `nlp_server_host`: The host of the service, override the default if the service is running on a different server
- `nlp_server_port`: Published port for the nlp-server endpoint
