# RabbitMQ role documentation

## RabbitMQ

The `rabbitmq` role supports starting a container that runs a single RabbitMQ node, along with monitoring.

### RabbitMQ Customization

The defaults are in `roles/rabbitmq/defaults/main.yml` and can be overriden in the inventory file:
- `rabbitmq_image_version`: Version tag of the image
- `rabbitmq_image_url`: URL for the image
- `rabbitmq_management_published_port`: Published port for the RabbitMQ Management endpoint
- `rabbitmq_prometheus_published_port`: Published port for the RabbitMQ Prometheus endpoint
- `rabbitmq_log_level`: Log level for RabbitMQ, see: https://www.rabbitmq.com/docs/logging#log-levels

The following variables have their default definitions in `common_vars/defaults/main.yml` since they are common variables:
- `rabbitmq_host`: The host where RabbitMQ is installed
- `rabbitmq_published_port`: Published port for the RabbitMQ endpoint
- `rabbitmq_username`: Sets a username for RabbitMQ
- `rabbitmq_vhost_xray_exporter`: Additional vhost for xray-exporter-csv
- `rabbitmq_password`: Sets a password for RabbitMQ

Two additional environment variables are needed to set the disk and memory limits.
- `rabbitmq_disk_free_absolute_limit`: Disk absolute free space limit of the partition on which RabbitMQ is storing data (takes precedence over the relative limit) (Should be at least double than the value of RMQ VM Memory setting)
- `rabbitmq_vm_memory_high_watermark`: High memory watermark for RabbitMQ to block publishers and prevent new messages from being enqueued.

#### RabbitMQ configuration directory

We are creating a conf.d-style directory of configuration files in `"{{ dxr_home }}/etc/rabbitmq/conf.d`, valid configuration files can dropped in there and will be loaded in alphabetical order. Please make sure the default configuration filed configured by Ansible is always loaded first. See here for more information: https://www.rabbitmq.com/docs/configure#config-confd-directory