# xray-ui role documentation

## xray-ui

The `xray_ui` role supports deploying and starting an `xray-ui` container.

### xray-ui customization:

The defaults are in `roles/xray_ui/defaults/main.yml` and can be overriden in the inventory file:
- `xray_ui_image_url`: URL for the image
- `xray_ui_image_version`: Version tag of the image that overrides the general `dxr_version` from the inventory file
- `xray_ui_port`: Published port for the xray-ui endpoint
- `xray_ui_enable_sharepoint`: Enables Sharepoint
- `xray_ui_enable_sharepoint_api`: Enables Sharepoint API
- `xray_ui_is_drag_and_drop_enabled`: Enables Drag & Drop
- `xray_ui_enable_box`: Enables the Box integration
