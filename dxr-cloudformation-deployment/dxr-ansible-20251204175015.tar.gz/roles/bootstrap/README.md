# Bootstrap role documentation

## Bootstrapping the server

What the role currently supports:
- Creating the users `ohalo` and setup ssh keys
- Creating the firewall rules and making them permanent
- Configuring Journald limits
- Install Podman

### Bootstrapping Customization

The defaults are in `group_vars/all.yml` and can be overriden in the inventory file when using `ansible-playbook` (or see here for alternatives: https://docs.ansible.com/ansible/latest/playbook_guide/playbooks_variables.html#understanding-variable-precedence):

- `dxr_home`: the default directory for the stack, usually `/opt/xray`
- `dxr_logs_directory`: the default log directory, usually `/var/log`
- `dxr_folder_datasources_path`: the default path for the folder connector feature, usually `/folder_datasources`

There are also defaults in the bootstrap roles, in `roles/bootstrap/defaults/main.yml`, and they can be overriden in the inventory file:

- `bootstrap_deploy_ssh_public_keys`: Boolean, if set to `true` enables the deployment of public ssh keys on the server(s). Defaults to `false`
- `bootstrap_ssh_public_keys_location`: Path to a file containing public ssh keys that will deployed to the `ohalo` user. One key per line. Important: must be a full path. Also important: this process is additive only, meaning it will not replace or delete existing ssh keys on the server, only add new keys, so you will need to remove them manually if needed. Defaults to `"{{ playbook_dir }}/roles/bootstrap/files/ohalo_internal_ssh_public_keys"`, which contains a set of Ohalo's engineers public ssh keys, so override this to another file if you want to deploy a different set of public ssh keys.
- `bootstrap_gclogs_hdump_clean_up_retention`: Integer, in days. The rounded file modification time used by the find command in the ohalo-gclogs-hdump-clean-up.service to delete older Java containers garbage collection logs and heap dumps files. Defaults to `30`, so any files that was modified over 30 days ago. See: https://linux.die.net/man/1/find
- `bootstrap_gclogs_hdump_clean_up_service_frequency`: The frequency at which the ohalo-gclogs-hdump-clean-up.service is ran, see https://www.freedesktop.org/software/systemd/man/latest/systemd.time.html# for a list of possible values and for more information on the syntax of calendar event expressions. Defaults to `monthly`.
- `bootstrap_containers_log_size_max`: Maximum size for the containers logs, to avoid filling up the disk, defaults to `1073741824`
- `bootstrap_ohalo_nofile_limit`: The nofile limit value that controls the maximum number of open files the ohalo can have, defaults to `65535`
- `bootstrap_firewalld_version`: default and supported version of firewalld
- `bootstrap_rsync_version`: default and supported version of rsync
- `bootstrap_podman_version`: default and supported version of podman
- `ghcr_username`: username to use when logging to the Github container registry ghcr.io
- `ghcr_token`: token to use when logging to the Github container registry ghcr.io
