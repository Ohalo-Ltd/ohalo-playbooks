# configure_frontend_containers role documentation

## Configure the DXR frontend containers

One of the challenges when creating the frontend roles is that xray-ui and xray-console have shared variables, and if we deployed these variables through one of those roles, we could have issues later down the road in case they are running on different servers, hence the `configure_frontend_containers` role to handle those shared variables.

### configure_frontend_containers customization

The defaults are in `roles/configure_frontend_containers/defaults/main.yml` and can be overriden in the inventory file.
