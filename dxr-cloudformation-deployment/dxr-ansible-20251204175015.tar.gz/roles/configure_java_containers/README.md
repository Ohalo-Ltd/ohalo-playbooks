# configure_java_containers role documentation

## Configure the DXR Java containers

One of the challenges when working with the DXR stack is that some containers have shared variables, and if we deployed these variables through one of those roles, we could have issues later down the road in case they are running on different servers, hence the `configure_java_containers` role to handle those shared variables.

This role also handles:

- creating the GC logs directory
- creating the hdump (memory dump) directory
- creating the keys directory, containing encryption keys for credentials (users, datasources, etc)

### configure_java_containers customization

The defaults are in `roles/configure_java_containers/defaults/main.yml` and can be overriden in the inventory file:

- `configure_java_containers_base_jvm_owner`: id of the user running the Java processes inside the container
- `configure_java_containers_base_jvm_group`: id of the group of the user running the Java processes inside the container
