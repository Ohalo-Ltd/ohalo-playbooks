# dlp-syncer role documentation

## dlp-syncer

The `dlp-syncer` role supports deploying and starting a `dlp-syncer` container.

### dlp-syncer customization:

The defaults are in `roles/dlp-syncer/defaults/main.yml` and can be overriden in the inventory file:
- `dlp_syncer_image_url`: URL for the image
- `dlp_syncer_image_version`: Version tag for the image
- `dlp_syncer_enabled`: Enables the deployment of dlp-syncer
- `dlp_syncer_extra_jvm_opts`: Additional JVM options to pass to the Java application. These options override `common_extra_jvm_opts` when specified. If empty, `common_extra_jvm_opts` will be used instead. Example: `"-Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false"`

#### Ms Graph Connection Timeouts

- `dlp_syncer_http_client_connect_timeout_duration`: Maximum time to establish a TCP connection to Ms Graph server
- `dlp_syncer_http_client_response_timeout_duration`: Total time allowed for the complete request-response cycle to Ms Graph server
- `dlp_syncer_http_client_read_timeout_duration`: Maximum idle time allowed when reading data from Ms Graph server
- `dlp_syncer_http_client_write_timeout_duration`: Maximum idle time allowed when sending data to Ms Graph server

#### Ms Graph Retry Configuration

- `dlp_syncer_http_client_max_attempts`: Total number of request attempts (original + retries) before aborting communication with Ms Graph server
- `dlp_syncer_http_client_minimum_backoff_period`: Initial wait time before the first retry attempt to Ms Graph server

The following variables have their default definitions in `common_vars/defaults/main.yml` since they are common variables:
- `common_extra_jvm_opts`: Default JVM options for all Java services using base-jvm. These options are used unless overridden by service-specific JVM options. Example: `"-Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false"`
- `dlp_syncer_port`: Published port for the dlp-syncer endpoint
- `dlp_syncer_host`: The host of the service