# host_monitoring role documentation

## host_monitoring

This role deploys a `node-exporter` container to monitor the host server that runs the containers.

### host_monitoring customization

The defaults are in `roles/host_monitoring/defaults/main.yml`, and can be overriden in the inventory file:
- `host_monitoring_node_exporter_image_url`: URL for the image
- `host_monitoring_node_exporter_image_version`: Version tag of the image
- `host_monitoring_node_exporter_port`: Published port for the node-exporter container