# Prometheus role documentation

## Prometheus

The `prometheus` role supports deploying and starting a `prometheus` container, including authentication for the Prometheus API.

### Prometheus customization:

The defaults are in `roles/prometheus/defaults/main.yml` and can be overriden in the inventory file:
- `prometheus_global_scrape_interval`: How frequently to scrape targets (gather metrics via http request). This is the global setting, which can be overriden in each target's section
- `prometheus_global_evaluation_interval`: How frequently to evaluate rules
- `prometheus_global_scrape_timeout`: How long until a scrape request times out
- `prometheus_username`: The username used for authenticating the Prometheus API
- `prometheus_image_url`: URL for the image
- `prometheus_image_version`: Version tag for the image
- `prometheus_federation_enabled`: Boolean, enables Prometheus federation in multi-nodes clusters
- `prometheus_main_federated_server`: Boolean, set to true on the server selected to be the main federated Prometheus instance that Grafana will pull metrics from.
- `prometheus_main_federated_server_host`: Used by Grafana to pull the metrics from the main federated Prometheus instance.
- `prometheus_main_federated_server_password`: Used by Grafana to set the password of the main federated Prometheus instance.
- `prometheus_password`: The password used for authenticating the Prometheus API

The following variables have their default definitions in `common_vars/defaults/main.yml` since they are common variables:
- `prometheus_host`: The host of the service, override the default if the service is running on a different server
- `prometheus_port`: Published port for the prometheus endpoint
- `prometheus_log_level`: Log level, can be set to: debug, info, warn or error. Default is "info"
