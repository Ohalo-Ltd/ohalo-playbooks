# Seaweed role documentation

## SeaweedFS

The `seaweed` role deploys a seaweed container

### Seaweed customization

The defaults are in `roles/seaweed/defaults/main.yml`, and they can be overriden in the inventory file:
- `seaweed_image_url`: URL for the image
- `seaweed_image_version`: Version tag of the image
- `seaweed_metrics_port`: Port for scraping metrics
- `seaweed_dxr_user`: Name of the user that DXR uses to authenticate requests to the SeaweedFS S3 endpoint, default is "dxr_user"
- `seaweed_elasticsearch_backup_user`: Name of the user that Elasticsearch uses to authenticate requests to the SeaweedFS S3 endpoint for backups, default is "elasticsearch-user"

The following variables have their default definitions in `common_vars/defaults/main.yml` since they are common variables:
- `seaweed_s3_http_host`: Host for the S3 endpoint
- `seaweed_s3_http_port`: Port for the S3 endpoint
- `blob_storage_access_key_id`: Access key, can be any alphanumerical string, you can use this command to generate the key id if you are using Seaweed: `openssl rand -base64 2000 | tr -dc 'A-Za-z0-9' | fold -w 30 | head -n 1`.
- `blob_storage_secret_access_key`: Secret for storage access, can be any long alphanumerical string, you can use this command to generate the access key if you are using Seaweed: `openssl rand -base64 2000 | tr -dc 'A-Za-z0-9' | fold -w 60 | head -n 1`.
