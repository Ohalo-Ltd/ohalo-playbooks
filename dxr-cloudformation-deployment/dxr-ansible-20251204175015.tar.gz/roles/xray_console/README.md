# xray-console role documentation

## xray-console

The `xray_console` role supports deploying and starting an `xray-console` container.

### xray-console customization:

The defaults are in `roles/xray_console/defaults/main.yml` and can be overriden in the inventory file:
- `xray_console_image_url`: URL for the image
- `xray_console_image_version`: Version tag of the image that overrides the general `dxr_version` from the inventory file
- `xray_console_port`: Published port for the xray-console endpoint
- `xray_console_api_docs_enabled`: Enables the API Docs tab. Default is `false`
