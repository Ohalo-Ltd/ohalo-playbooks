# create_log_files role documentation

## Logging

The logging is handled by the `create_log_files` role.

What this role handles:
- create the log directory and logfile
- create the rsyslog.d configuration file and apply it by restart the rsyslog service
- create the logrotate configuration file

### Logging Customization

The defaults are in `roles/create_log_files/defaults/main.yml` and can be overriden in the inventory file:

- `create_log_files_logrotate_default_maxsize`: Maximum size of the log file before rotating
- `create_log_files_logrotate_default_retention_in_days`: Number of days that the log files are kept
- `create_log_files_logrotate_default_frequency`: log rotation frequency
- `create_log_files_logrotate_default_maxage`: log maximum age in days before deleting, can probably be removed in favour of the retention setting