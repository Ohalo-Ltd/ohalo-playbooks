# Grafana role documentation

## Grafana

The `grafana` role supports deploying and starting a `grafana` container, including configuration for Prometheus and dashboards for all components of the stack.

### Grafana customization:

The defaults are in `roles/grafana/defaults/main.yml` and can be overriden in the inventory file:
- `grafana_image_url`: URL for the image
- `grafana_image_version`: Version tag for the image
- `grafana_port`: Published port for the Grafana endpoint
- `grafana_alerting_enabled`: Enable alerting (default is false)
- `grafana_alerting_slack_receiver_uid`: UID for the alerting Slack receiver. This simply needs to be a unique id of your choice.
- `grafana_alerting_slack_url`: URL for sending out alerts to Slack
- `grafana_metrics_username`: The username used by Prometheus to scrape Grafana's metrics
- `grafana_log_level`: Log level for the Grafana logs (default is `info`)
- `grafana_admin_password`: Admin password for the Grafana UI
- `grafana_metrics_password`: The password used by Prometheus to scrape Grafana's metrics

### Grafana configuration and alerting

For more information about setting up Grafana and how to configure alerting, please refer to the dedicated documentation section in [docs/grafana.md](docs/grafana.md).