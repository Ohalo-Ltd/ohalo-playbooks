# identity_saml

The `identity_saml` role supports deploying and starting an identity-saml container. This container is used for SAML 2.0 Single Sign-On (SSO) integration for Data X-Ray.

Please note that `identity_saml_enabled` needs to be set to `true` in the inventory file for the container to be deployed. 

## identity-saml customization

The defaults are in `roles/identity_saml/defaults/main.yml` and can be overridden in the inventory file:

- `identity_saml_image_url`: The URL for the identity-saml Docker image, defaults to `ghcr.io/ohalo-ltd/identity-saml/identity-saml`
- `identity_saml_port`: The port for the identity-saml service, defaults to `8079`
- `identity_saml_debug_port`: The debug port for the identity-saml service, defaults to `28079`
- `identity_saml_jmx_port`: The JMX port for the identity-saml service, defaults to `10079`
- `identity_saml_url`: The URL for the identity-saml service, defaults to `host.containers.internal`
- `identity_saml_frontend_url`: The frontend URL for SAML redirects, defaults to `{{ server_url }}`
- `identity_saml_enabled`: Enables the deployment of identity-saml, set in the inventory file
- `identity_saml_extra_jvm_opts`: Additional JVM options to pass to the Java application. These options are appended to the standard JVM configuration. Example: `"-Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false"`

## Required SAML Configuration

The following properties must be set in your inventory file:

- `identity_saml_idp_metadata_uri`: URL to fetch your IdP's SAML metadata

For a cluster configuration, this configuration should be added to the "backend" host in the inventory file.

## Optional SAML Configuration

The following properties can be set in your inventory file:

- `identity_saml_sp_private_key_path`: Path to your SAML private key file (.pem format)
- `identity_saml_sp_certificate_path`: Path to your SAML X.509 certificate file (.crt format)
- `identity_saml_email_attribute`: SAML attribute name for user email (default: "email")
- `identity_saml_given_name_attribute`: SAML attribute name for user first name (default: "givenName")
- `identity_saml_family_name_attribute`: SAML attribute name for user last name (default: "familyName")
- `identity_saml_groups_attribute`: SAML attribute name for user groups (default: "groups")

For a cluster configuration, this configuration should be added to the "backend" host in the inventory file.