# Nginx role documentation

## Nginx

The `nginx` role supports deploying and starting an `nginx` container. The configuration specific to each component is preferably handled in their respective playbooks.

### Nginx customization:

The defaults are in `roles/nginx/defaults/main.yml` and can be overriden in the inventory file:
- `nginx_image_url`: URL for the image
- `nginx_image_version`: Version tag for the image
- `nginx_port`: Published port for Nginx, please note it's set both on the container definition and in the proxy_block.conf template
- `nginx_ssl_cert_crt_filename`: Name for the crt file of the SSL certificate
- `nginx_ssl_cert_key_filename`: Name for the private key file of the SSL certificate
- `nginx_path_to_ssl_cert_and_key_dir`: If defined, Ansible will pull the Nginx certificate and key files recursively from the specified directory (full) path, otherwise it will generating self-signed certificates using OpenSSL. Important: must be a full path, otherwise Ansible will try to use roles/nginx/files as the base directory, which does not exist. The certificate files must be located on the control node (the machine running Ansible). Also the filenames of the crt and key files must match the value of `nginx_ssl_cert_key_filename` and nginx_ssl_cert_key_filename (defaults: server.crt and server.key, see `roles/nginx/defaults/main.yml`)
- `nginx_self_signed_cert_location`: Used for generating an SSL certificate using OpenSSL, corresponds to the location of the organization that generates the cert
- `nginx_self_signed_cert_organization`: Used for generating an SSL certificate using OpenSSL, corresponds to name of the organization that generates the cert
- `nginx_self_signed_cert_email`: Used for generating an SSL certificate using OpenSSL, corresponds to the email contact associated with the cert
- `nginx_image_uid`: User ID of the user starting the Nginx process inside the container
- `nginx_image_gid`: Group ID of the user starting the Nginx process inside the container

### Nginx SSL certificates

Unless the SSL certificates are supplied using `nginx_path_to_ssl_cert_and_key_dir`, self-signed SSL certificates will be generated during the deployment. They will not be regenerated as long as the .crt file exists, if the certificates need to be updated or regenerated, simply delete the SSL certificates .crt and .key files like so (replacing {{ dxr_home }} with the actual path, usually `/opt/xray`, and {{ nginx_ssl_cert_key_filename }} with the actual file name, usually `server` by default):
```
rm -f {{ dxr_home }}/certs/{{ nginx_ssl_cert_key_filename }}.crt {{ dxr_home }}/certs/{{ nginx_ssl_cert_key_filename }}.key
```
and re-run the the deployment.