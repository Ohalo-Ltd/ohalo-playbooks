# xray-diagnostics role documentation

## xray-diagnostics

The `xray_diagnostics` role supports deploying and starting an `xray-diagnostics` container.

### xray-diagnostics customization:

The defaults are in `roles/xray_diagnostics/defaults/main.yml` and can be overriden in the inventory file:
- `xray_diagnostics_image_url`: URL for the image
- `xray_diagnostics_image_version`: Version tag for the image
- `xray_diagnostics_main_node`: Used for multi-servers deployments only. Indicates if the server running xray-diagnostics is the main instance or not (worker). Should be set as `true`  on the same server as xray-api.
- `xray_diagnostics_extra_jvm_opts`: Additional JVM options to pass to the Java application. These options are appended to the standard JVM configuration. Example: `"-Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false"`

The following variables have their default definitions in `common_vars/defaults/main.yml` since they are common variables:
- `xray_diagnostics_host`: The host of the service
- `xray_diagnostics_port`: Published port for the xray-diagnostics endpoint
