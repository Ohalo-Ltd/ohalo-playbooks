# xray-exporter-csv role documentation

## xray-exporter-csv

The `xray_exporter_csv` role supports deploying and starting an `xray-exporter-csv` container.

### xray-exporter-csv customization:

The defaults are in `roles/xray_exporter_csv/defaults/main.yml` and can be overriden in the inventory file:
- `xray_exporter_csv_image_url`: URL for the image
- `xray_xporter_csv_image_version`: Version tag for the image
- `xray_exporter_csv_dramatiq_time_limit`: Increase the time available for CSV exports to be generated. Default is 10 minutes.

The following variables have their default definitions in `common_vars/defaults/main.yml` since they are common variables:
- `xray_exporter_csv_host`: Host running the service
- `xray_exporter_csv_port`: Published port for xray-exporter-csv
