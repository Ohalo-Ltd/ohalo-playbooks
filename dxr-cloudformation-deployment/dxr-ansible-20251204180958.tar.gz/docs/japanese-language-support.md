# Deployment procedure to support the Japanese language

The goal of this guide is to add support for the Japanese language on the Data X-Ray stack when using the Ansible deployment.

## 1. Override the containers images default value

### a. document-ingester-elasticsearch

For `document-ingester-elasticsearch`, override the `document_ingester_elasticsearch_image_url` variable with the following URL: `ghcr.io/ohalo-ltd/document-ingester-elasticsearch/document-ingester-elasticsearch-jpn`

### b. nlp-server

For `nlp-server`, override the `nlp_server_image_url` variable with the following URL: `ghcr.io/ohalo-ltd/nlp-server/nlp-server-jp`

## 2. Override the text extraction OCR language default value

Override the default value for the text extraction OCR language variable `document_ingester_elasticsearch_tesseract_ocr_language`:
- eng : extract english text (default value)
- jpn : extract japanese text, this requires the japanese enabled images as described above (ghcr.io/ohalo-ltd/document-ingester-elasticsearch/document-ingester-elasticsearch-jpn and ghcr.io/ohalo-ltd/nlp-server/nlp-server-jp)
 
Note: Only document-ingester-elasticsearch-jpn can currently support multiple languages separated by a '+' character, i.e. jpn+eng : extract japanese and english text. Since nlp-server can only support one or the other, please do not use multiple languages at this point. Also note that selecting multiple languages impacts the performance of the OCR process.