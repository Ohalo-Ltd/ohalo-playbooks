# document-ingester-elasticsearch role documentation

## document-ingester-elasticsearch

The `document_ingester_elasticsearch` role supports deploying and starting a `document-ingester-elasticsearch` container, including support for deploying the demo_files via the `folder_datasources` role.

### document-ingester-elasticsearch customization:

The defaults are in `roles/document_ingester_elasticsearch/defaults/main.yml` and can be overriden in the inventory file:

- `document_ingester_elasticsearch_image_version`: Version tag of the image that overrides the general `dxr_version` from the inventory file
- `document_ingester_elasticsearch_image_url`: URL for the image
- `document_ingester_elasticsearch_heap_size`: JVM Heap size, see the `-Xmx` section here: https://docs.oracle.com/en/java/javase/17/docs/specs/man/java.html#extra-options-for-java. Specifies the maximum size (in bytes) of the heap. This value must be a multiple of 1024 and greater than 2 MB. Append the letter k or K to indicate kilobytes, m or M to indicate megabytes, or g or G to indicate gigabytes.
- `document_ingester_elasticsearch_extra_jvm_opts`: Additional JVM options to pass to the Java application. These options override `common_extra_jvm_opts` when specified. If empty, `common_extra_jvm_opts` will be used instead. Example: `"-Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false"`
- `document_ingester_elasticsearch_diagnostic_log_filenames_enabled`: Diagnostic logging
- `document_ingester_elasticsearch_file_parser_timeout_seconds`: Time out for text extraction and OCR process of files of each individual file parser worker.
- `document_ingester_elasticsearch_tesseract_ocr_language`: Text extraction OCR language, requires using the appropriate images. Valid values: `eng` or `jpn` Please refer to the [Japanese language support section](../../docs/japanese-language-support.md) for more information.
- `document_ingester_elasticsearch_datasource_eod_check_period_milliseconds`: Defines how many miliseconds to wait between checks for the indexing of a datasource to be complete.
- `document_ingester_elasticsearch_file_downloader_thread_count`: Number of files that can be downloaded concurrently
- `document_ingester_elasticsearch_datasource_manager_thread_count`:
- `document_ingester_elasticsearch_datasource_crawler_thread_count`: number of consumers for running parallel crawls (should match the expected number of datasources)
- `document_ingester_elasticsearch_file_parser_thread_count`: Make sure the sum of file-parser consumers and gunicorn workers doesn't exceed the number of available CPUs (leaving some headroom for other processes)
- `document_ingester_elasticsearch_entity_extractor_thread_count`: It is recommended to use the same number as the nlp-server workers
- `document_ingester_elasticsearch_file_tagger_thread_count`: Maximum number of consumers configured for the file tagger process
- `document_ingester_elasticsearch_datasource_indexer_thread_count`: Maximum number of consumers configured for the datasource indexer process
- `document_ingester_elasticsearch_datasource_tracker_thread_count`: Maximum number of consumers configured for the datasource tracker process
- `document_ingester_elasticsearch_datasource_recrawler_thread_count`: number of consumers for running parallel recrawls for the datasource recrawler process
- `document_ingester_elasticsearch_file_downloader_max_fps`: To avoid overwhelming the file parser, the downloader consumers can have their throughput limited. We express the max throughput in files-per-second
- `document_ingester_elasticsearch_document_categorizer_document_finder_mq_concurrent_consumers`: The number of worker threads processing categorization queries, default value is 1
- `document_ingester_elasticsearch_document_categorizer_document_processor_mq_concurrent_consumers`: The number of worker threads categorizing documents, default value is 1
- `document_ingester_elasticsearch_document_categorizer_job_time_to_live`: How long completed document categorizer jobs last before being cleaned up, expressed as an ISO8601 duration. Default is 30 days.
- `document_ingester_elasticsearch_document_categorizer_cleanup_job_interval`: Interval at which clean up is performed, expressed as an ISO8601 duration. Default is 1 day.
- `document_ingester_elasticsearch_datasource_file_count_update_duration`: duration between MongoDB file count queries, ISO8601 duration
- `document_ingester_elasticsearch_generic_ocr_ratelimiter_requests`: Rate limiter setting for Generic OCR processor, number of requests per period. Default 120 requests
- `document_ingester_elasticsearch_generic_ocr_ratelimiter_period`: Rate limiter setting for Generic OCR processor, period in the ISO-8601 duration format PnDTnHnMn.nS. Default "PT1M"

The following variables have their default definitions in `common_vars/defaults/main.yml` since they are common variables:
- `common_extra_jvm_opts`: Default JVM options for all Java services using base-jvm. These options are used unless overridden by service-specific JVM options. Example: `"-Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false"`
- `document_ingester_elasticsearch_host`: The host of the service, override the default if the service is running on a different server
- `document_ingester_elasticsearch_port`: Published port for the document-ingester-elasticsearch endpoint
- `blob_storage_enabled`: Configures a blob storage as document-ingester-elasticsearch temporary storage (otherwise the default is the local filesystem) and as xray-api storage. Boolean, default is `true`
- `blob_storage_region`: Sets the region for the blob storage
- `blob_storage_endpoint`: Sets the endpoint for the blob storage
- `blob_storage_force_path_style`: Force S3 client to use "path style" requests (see https://docs.aws.amazon.com/AmazonS3/latest/userguide/VirtualHosting.html)
- `blob_storage_retry_max_attempts`: Maximum number of retry to connect to the blob storage, default to `30`
- `blob_storage_retry_base_delay`: Base retry delay to connect to the blob storage, defaults to `"PT5S"`
- `blob_storage_retry_max_delay`: Maximum retry delay to connect to the blob storage, defaults to `"PT60S"`
- `blob_storage_access_key_id`: Access key for the blob storage, you can use this command to generate the key id when using Seaweed (can be any alphanumerical string): `openssl rand -base64 2000 | tr -dc 'A-Za-z0-9' | fold -w 30 | head -n 1`.
- `blob_storage_secret_access_key`: Secret for the blob storage, you can use this command to generate the access key when using Seaweed (can be any long alphanumerical string): `openssl rand -base64 2000 | tr -dc 'A-Za-z0-9' | fold -w 60 | head -n 1`.
