# identity-azure-ad role documentation

## identity-azure-ad

The `identity_azure_ad` role supports deploying and starting an identity-azure-ad container. This container is used for Azure AD / Microsoft Entra ID integration feature.

Please note that `identity_azure_ad_enabled` needs to be set to `true` in the inventory file for the container to be deployed.

### identity-azure-ad customization:

The defaults are in `roles/identity_azure_ad_enabled/defaults/main.yml` and can be overriden in the inventory file:
- `identity_azure_ad_image_url`: URL for the image
- `identity_azure_ad_image_version`: Version tag for the image
- `identity_azure_ad_port`: Published port for the identity-azure-ad endpoint
- `identity_azure_ad_url`: the URL for the Nginx configuration file, if not set it will default to `host.containers.internal`. Please override this to the frontend URL in the inventory file for multi-servers clusters
- `identity_azure_ad_azure_ad_client_id`: Application (client) ID on the App registration on Azure, see here https://docs.ohalo.co/advanced/azure-ad/ for more information
- `identity_azure_ad_azure_ad_client_secret`: Client secret on the App registration on Azure (under "Certificates & secrets"), see here https://docs.ohalo.co/advanced/azure-ad/ for more information
- `identity_azure_ad_extra_jvm_opts`: Additional JVM options to pass to the Java application. These options are appended to the standard JVM configuration. Example: `"-Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false"`

The following variables have their default definitions in `common_vars/defaults/main.yml` since they are common variables:
- `identity_azure_ad_enabled`: Enables the deployment of identity-azure-ad, set in the inventory file
- `identity_azure_ad_oauth_url`: URL for the Azure AD integration OAuth (used on the frontends containers)
- `identity_azure_ad_ad_iam_manager`: Group for Super Admin Roles, see here https://docs.ohalo.co/advanced/azure-ad/ for more information
- `identity_azure_ad_azure_ad_tenant_id`: Directory (tenant) ID on the App registration on Azure, see here https://docs.ohalo.co/advanced/azure-ad/ for more information
