# Mongo role documentation

## Mongo

The `mongo` role supports starting a container that runs a single node MongoDB instance, along with monitoring.
What the role currently supports:
- Configure and start a Mongo container that matches our regular deployments
- Configure monitoring for the Mongo container
- Run xray-mongodb-migrator to update the Mongo database

### MongoDB Customization

The defaults are in `roles/mongo/defaults/main.yml` and can be overriden in the inventory file:
- `mongo_image_url`: URL for the MongoDB image
- `mongo_image_version`: Version tag of the MongoDB image

The following variables have their default definitions in `common_vars/defaults/main.yml` since they are common variables:
- `mongo_host`: Host for the MongoDB endpoint
- `mongo_published_port`: Published port for the MongoDB endpoint
- `mongo_service_password`: Sets the password for the mongo service user
- `mongo_admin_password`: Sets the password for the mongo admin user

### xray-mongodb-migrator

The `xray_mongodb_migrator` container is run as part of the mongo role.

#### xray-mongodb-migrator customization

The defaults are in `roles/mongo/defaults/main.yml` and can be overriden in the inventory file:
- `mongo_xray_mongodb_migrator_image_version`: Version tag of the image that overrides the general `dxr_version` from the inventory file
- `mongo_xray_mongodb_migrator_image_url`: URL for the image
