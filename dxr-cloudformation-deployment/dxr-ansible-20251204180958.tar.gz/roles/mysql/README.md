# MySQL role documentation

## MySQL

What the role currently supports:
- Creating the relevant log files and rsyslog/logrotate configs
- Configure and start a MySQL container that matches our regular deployments
- Configure monitoring for the MySQL container
- Run xray-db-migrator to update the MySQL databases
- Create separate DB and users for other microservices

### MySQL Customization

The defaults are in `roles/mysql/defaults/main.yml` and can be overridden in the inventory file:

- `mysql_image_version`: MySQL version
- `mysql_image_url`: URL for the MySQL 
- `mysql_published_port`: Published port for the MySQL endpoint
- `mysql_root_password`: Sets the admin root password for MySQL

### MySQL monitoring

We have to run an extra container that we call `mysql-exporter` and that provides metrics for MySQL so they can be scraped by Prometheus, as it doesn't have that feature by default. We are using this: https://github.com/prometheus/mysqld_exporter

The defaults are in `roles/mysql/defaults/main.yml` and can be overriden in the inventory file:
- `mysql_exporter_image_url`: URL for the image
- `mysql_exporter_image_version`: Version tag for the image
- `mysql_exporter_published_port`: Published port for the mysql-exporter endpoint
- `mysql_exporter_password`: The password for the MySQL user `exporter`, used to create the metrics

### xray-db-migrator

The `xray_db_migrator` container is run as part of the mysql role.

#### xray-db-migrator customization

The defaults are in `roles/mysql/defaults/main.yml` and can be overriden in the inventory file:
- `mysql_xray_db_migrator_image_version`: Version tag of the image that overrides the general `dxr_version` from the inventory file
- `mysql_xray_db_migrator_image_url`: URL for the image

### MySQL Metadata Extractor

The creation of the database and user for the metadata-extractor microservice is handled by the MySQL role. You can set the password for it in the inventory file:
- `mysql_metadata_extractor_password`: The password for the MySQL user `metadata_extractor`, which is used to access the `metadata_extractor` database.

