# validate_identity_config role documentation

## Validate DXR identity

This role ensures that Azure AD, SAML SSO, and SCIM are configured in a compatible combination before deployment begins. Since these identity features have specific interdependencies and mutual exclusions, validating them early prevents wasted time troubleshooting unsupported configurations.

### Configuration rules

- **SCIM requires SAML**: SCIM can only be enabled when SAML SSO is also enabled
- **Azure AD and SAML are mutually exclusive**: Both cannot be enabled simultaneously

### Valid configuration combinations

| Azure AD | SAML | SCIM | Valid | Notes |
|----------|------|------|-------|-------|
| false    | false| false| ✅     | No identity features enabled |
| false    | false| true | ❌     | SCIM requires SAML |
| false    | true | false| ✅     | SAML only |
| false    | true | true | ✅     | SAML with SCIM |
| true     | false| false| ✅     | Azure AD only |
| true     | false| true | ❌     | SCIM requires SAML |
| true     | true | false| ❌     | Azure AD and SAML are mutually exclusive |
| true     | true | true | ❌     | Azure AD and SAML are mutually exclusive |

### validate_identity_config customization

The defaults are in `roles/validate_identity_config/defaults/main.yml` and can be overridden in the inventory file.
