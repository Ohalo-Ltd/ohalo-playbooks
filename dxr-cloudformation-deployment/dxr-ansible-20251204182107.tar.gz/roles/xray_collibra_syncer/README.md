# xray-collibra-syncer role documentation

## xray-collibra-syncer

The `xray_collibra_syncer` role supports deploying and starting an `xray-collibra-syncer` container.

### xray-collibra-syncer customization:

The defaults are in `roles/xray_collibra_syncer/defaults/main.yml` and can be overridden in the inventory file:

- `xray_collibra_syncer_image_url`: URL for the image
- `xray_collibra_syncer_image_version`: Version tag for the image
- `xray_collibra_syncer_import_size`: Maximum number of resources the syncer is adding to each batch-file that is adding to a synchronization process of a datasource. Default value 700. Maximum supported is 50000.
- `xray_collibra_syncer_enabled`: Enables the deployment of xray-collibra-syncer
- `xray_collibra_syncer_extra_jvm_opts`: Additional JVM options to pass to the Java application. These options are appended to the standard JVM configuration. Example: `"-Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false"`

The following variables have their default definitions in `common_vars/defaults/main.yml` since they are common variables:
- `xray_collibra_syncer_host`: The host of the xray-collibra-syncer endpoint
- `xray_collibra_syncer_port`: Published port for the xray-collibra-syncer endpoint
